print("*                                                        *")

number = float(input("Digite um número para saber se ele é positivo ou negativo: "))

print("----------------------------------------------------------")

if number <0:
    print("O número é negativo")
else:
    print("O número é positivo")