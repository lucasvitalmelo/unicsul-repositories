n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

if n1>n2:
    print("O ", n1, " é maior que o ", n2)
elif n2>n1:
     print("O ", n2, " é maior que o ", n1)