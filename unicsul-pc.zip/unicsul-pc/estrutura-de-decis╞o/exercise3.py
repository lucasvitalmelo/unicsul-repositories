sex = input('Digite (F), para feminino ou (M) para masculino :').upper()

if sex == 'F': 
    print("Feminino")
elif sex == 'M': 
    print("Masculino")
else:
    print("Sexo inválido")
