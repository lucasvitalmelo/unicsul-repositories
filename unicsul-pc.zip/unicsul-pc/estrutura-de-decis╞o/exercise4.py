digit = input("Coloque apenas um digito qualquer:")

if digit == "a" or digit == "A":
    print("Vogal")
elif digit == "e" or digit == "E":
    print("Vogal")
elif digit == "i" or digit == "I":
    print("Vogal")
elif digit == "o" or digit == "O":
    print("Vogal")
elif digit == "u" or digit == "U":
    print("Vogal")
elif digit == "0" or digit == "1" or digit == "2" or digit == "3" or digit == "4" or digit == "5" or digit == "6" or digit == "7" or digit == "8" or digit == "9": 
    print("Número")
else:
    print("Consoante")