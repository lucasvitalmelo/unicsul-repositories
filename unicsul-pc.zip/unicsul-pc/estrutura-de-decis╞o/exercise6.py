n1 = int(input("Digite o primeiro número:"))
n2 = int(input("Digite o segundo número:"))
n3 = int(input("Digite o terceiro número:"))

print("-----RESULTADO-----")

if n1>n2 and n2>n3:
    print("O número", n1," é o maior")
    print("O número", n2," é o do meio")
    print("O número", n3," é o menor")
