# 1.0

note1 = int(input("Digite o a nota da primeira avaliação: "))
note2 = int(input("Digite o a nota da segunda avaliação: "))

average = (note1+note2)/2
    
if avarage>= 10:
    print("Aprovado com Distinção") 

elif average>= 7:
    print("Aprovado")

else:
    print("Reprovado")


