resp='s'
lista=[]
while(resp=='s' or resp=='S'):
    x = int(input('Digite um número: '))
    lista.append(x)
    resp = input('Digite "S" para continuar: ')

tamanho = len(lista)
acum = 0
for n in range(tamanho):
    acum = acum+lista[n]