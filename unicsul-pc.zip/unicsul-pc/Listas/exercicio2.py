resp = 's'
volume = []
semana = []
for i in range(10):
    semana.append(input('Digite o dia da semana: ').lower())
    volume.append(float(input('Digite o volume do dia: ')))

media=0
acum=0
i=0
for i in range(10):
    if(semana[i]=='quarta-feira'):
        acum=acum + volume[i]
        i=i+1
media=acum/i
print('o valor acumulado das chuvas às quarta é de:%.3f' %acum)
print('o valor médio das chuvas às quarta é de:%.3f' %media)
