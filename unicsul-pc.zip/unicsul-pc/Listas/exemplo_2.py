lista=[]
resp='s'
while(resp=='s' or resp=='S'):
    num=int(input("Digite um número: "))
    lista.append(num)
    resp=input("Digite s para continuar: ")

acum=0
for i in range(len(lista)):
    acum=acum+lista[i]

media=acum/len(lista)
print("A média é: ", media)

acum2=0
for i in range(len(lista)):
    if(lista[i]>media):
        acum2=acum2+1
print("nesta lista temos ",acum2, "número acima da media")
