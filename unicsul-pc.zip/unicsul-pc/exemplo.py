placas = []
multas = []

resp="s"
while(resp=='s' or resp=='S'):
    placas.append(input("digite a placa: "))
    multas.append(float(input("digite o valor da multa: ")))
    resp=input("Digite s para continua")

acum=0
for n in range(len(multas)):
    acum = acum+(float(multas(n)))

media=acum/len(multas) 

print("media")