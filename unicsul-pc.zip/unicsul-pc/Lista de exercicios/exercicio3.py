name = input("Digite o nome do funcionario: ")
HM = float(input("Digite o total de horas mensais trabalhadas: "))
HE = float(input("Digite o totla de horas extras: "))
F = int(input("Digite o total de faltas: "))

HT = HE+(HM- F*8)

print("--------------------------------------")

print("O total de horas trabalhadas é :", HT)