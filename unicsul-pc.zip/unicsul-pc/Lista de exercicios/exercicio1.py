a=float(input("Digite o primeiro valor: "))
b=float(input("Digite o segundo valor: "))
c=float(input("Digite o terceiro valor: "))

total = a*a - (2*b) / (3*c) + a/6

print("O resultado dessa expressão é: %.2f"%total)