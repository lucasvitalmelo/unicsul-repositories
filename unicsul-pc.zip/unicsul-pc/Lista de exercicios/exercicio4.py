print("-------------------------------------")
print("Digite o código para o exame desejado")
print("-------------------------------------")

print('Código "A" para o exeme de Angiogracia - R$:155,50')
print('Código "B" para o exeme de Venografia  - R$:95,50')
print('Código "C" para o exeme de Urografia   - R$:387,95')
print('Código "D" para o exeme de Ultrasson   - R$:79,99')

print("------------------------------")

cod = input("Digite o código de exane: ").upper()

print("------------------------------")

if cod == "A":
    print("Angiogracia - R$:155,50")

elif cod == "B":
    print("Venografia - R$:95,50")

elif cod == "C":
    print("Urografia - R$:387,95")

elif cod == "D":
    print("Ultrasson - R$:79,99")

else:
    print("Não realizamos esse exame")
