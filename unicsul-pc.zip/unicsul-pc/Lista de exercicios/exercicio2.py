years = int(input("Digite sua idade: "))

if years>=18 and years<=69:
    print("Obrigatorio")

elif years==16 or years==17 or years>=70:
    print("Facultativo")

else:
    years<16
    print("Não é eleitor")