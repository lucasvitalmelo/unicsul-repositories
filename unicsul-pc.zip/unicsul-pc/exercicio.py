print('-----------------------------------------------')

alunos = []

notas = []

cursos = []

cursosTads = 0

alunosAcimaDaMedia = 0





while True:

    aluno = input("Digite o nome do aluno: ")

    nota = float(input("Digite a nota: "))

    curso = input("Digite o nome do cursos(ccp ou tads): ").lower()



    alunos.append(aluno)

    notas.append(nota)

    cursos.append(curso)



    if(curso == 'tads'):

        cursosTads += 1



    resp = input('\nDigite (sair) ou (enter) para continuar: ').lower()



    print('-----------------------------------------------')

    if resp == "sair":

        break





totalDeNotas = len(notas)

somaDeNotas = sum(notas)



mediaDeNotas = somaDeNotas / totalDeNotas





print(f'\nA quantidade de alunos do curso de tads é: {cursosTads}')

print(f'A média de notas dos alunos foi: {mediaDeNotas:.02f}')



for nota in notas:

    if (nota > mediaDeNotas):

        alunosAcimaDaMedia += 1

print(

    f'A quantidade de alunos que estão acima da média é: {alunosAcimaDaMedia}')