# Faça um programa que leia a largura e a altura de uma parede em metros, 
# calcule a sua área e a quantidade de tinta necessária para pintá-la, 
# sabendo que cada litro de tinta pinta uma área de 2 metros quadrados.
print("\n-------------------------------------------\n")
largura = float(input("Digite a largura da parede: "))
altura = float(input("Digite a altura da parede: "))
print("\n-------------------------------------------\n")

area = (largura * altura)
print("\n-------------------------------------------\n")
print("A parede tem {}m².\nPara pinta-lá será necessario {}l de tinta.".format(area, area/2))
print("\n-------------------------------------------\n")
