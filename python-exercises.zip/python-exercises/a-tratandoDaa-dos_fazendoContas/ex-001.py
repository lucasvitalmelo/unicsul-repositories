# Crie um programa que escreva "Hello World!" na tela.

print("Hello World")