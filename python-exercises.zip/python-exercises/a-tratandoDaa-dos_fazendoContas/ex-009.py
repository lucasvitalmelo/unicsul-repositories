# Faça um programa que leia um número Inteiro qualquer e mostre na tela a sua tabuada.

n = int(input("Digite um número: "))

print("{} x {} = {}".format(1, n, n*1))
print("{} x {} = {}".format(2, n, n*2))
print("{} x {} = {}".format(3, n, n*3))
print("{} x {} = {}".format(4, n, n*4))
print("{} x {} = {}".format(5, n, n*5))
print("{} x {} = {}".format(6, n, n*6))
print("{} x {} = {}".format(7, n, n*7))
print("{} x {} = {}".format(8, n, n*8))
print("{} x {} = {}".format(9, n, n*9))
print("{} x {} = {}".format(10, n, n*10))