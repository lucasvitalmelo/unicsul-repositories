# Faça um programa que leia um número Inteiro e mostre na tela o seu sucessor e seu antecessor.

n = int(input("Digite um número: "))

successor = n + 1

predecessor = n - 1

print("O antecessor de", n, "é", predecessor, "e o sucessor é", successor,)