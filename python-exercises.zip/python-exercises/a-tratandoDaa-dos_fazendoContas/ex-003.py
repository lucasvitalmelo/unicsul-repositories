# Crie um programa que leia dois números e mostre a soma entre eles.

n1 = int(input("Digite um número: "))
n2 = int(input("Digite mais um número: "))

soma = n1 + n2

print("A soma de", n1, "+", n2, "é", soma)