# Escreva um programa que pergunte a quantidade de Km percorridos por um carro alugado
# e a quantidade de dias pelos quais ele foi alugado. Calcule o preço a pagar, 
# sabendo que o carro custa R$60 por dia e R$0,15 por Km rodado.

print("================================================================\n")

dias = int(input("Dias alugados: "))
km = float(input("Km rodado: "))

total = (dias * 60) + (km * 0.15)

print("\n=================================================================\n")
print("O valor total a ser pago pelo carro alugado é {:.2f}".format(total))
print("\n=================================================================")