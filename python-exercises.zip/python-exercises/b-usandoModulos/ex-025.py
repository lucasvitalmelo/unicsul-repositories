# Crie um programa que leia o nome de uma pessoa e diga se ela tem “SILVA” no nome.

print("\n___________________________________\n")

name = str(input('Digite um nome completo: ')).strip().lower()
print('Tem silva? : ', 'silva' in name)

print("\n____________________________________")

