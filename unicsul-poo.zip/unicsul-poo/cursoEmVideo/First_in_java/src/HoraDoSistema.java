import java.util.Date;

public class HoraDoSistema {
    public static void main(String[] args) throws Exception {
        Date relogio = new Date();
        System.out.println("A hora do seu sistema é");
        System.out.println(relogio.toString());

    }
}
