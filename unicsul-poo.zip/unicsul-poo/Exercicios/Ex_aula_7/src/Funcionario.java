class Funcionario {
 private int cracha;
 private Float salario;
 private String cargo;

 public Funcionario(int cracha) {
  this.cracha = cracha;
}


 
}
