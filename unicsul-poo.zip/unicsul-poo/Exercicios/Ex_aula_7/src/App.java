public class App {
    public static void main(String[] args) throws Exception {
        Funcionario f1 = new Funcionario();

        f1.cracha = 1;
        
        System.out.println("Hello, World!");
    }
}
