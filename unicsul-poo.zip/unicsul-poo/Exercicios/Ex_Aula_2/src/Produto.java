public class Produto {
  String marca;
  String fabricante; 
  String cod_barras;
  float preco;
  
  public String getMarca() {
    return marca;
  }
  public void setMarca(String marca) {
    this.marca = marca;
  }
  public String getFabricante() {
    return fabricante;
  }
  public void setFabricante(String fabricante) {
    this.fabricante = fabricante;
  }
  public String getCod_barras() {
    return cod_barras;
  }
  public void setCod_barras(String cod_barras) {
    this.cod_barras = cod_barras;
  }
  public float getPreco() {
    return preco;
  }
  public void setPreco(float preco) {
    this.preco = preco;
  }
}
