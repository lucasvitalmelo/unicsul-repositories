public class Cliente {

  Integer id;
  String name;
  String document;
  
}
