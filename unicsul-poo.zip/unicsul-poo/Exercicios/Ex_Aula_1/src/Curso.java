public class Curso {
  Integer id;
  String name;
}
