public class App {
    public static void main(String[] args) throws Exception {
        Paciente paciente1 = new Paciente("Jessica");
        Paciente paciente2 = new Paciente("");
        System.out.println("Hello, World!");
    }
}
