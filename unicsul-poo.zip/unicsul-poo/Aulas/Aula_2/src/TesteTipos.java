public class TesteTipos {
  //atributos

  /* treino de criar atributos de cada tipo primitivo */

  //valores inteiros
  byte idade;
  short numero;
  int codigo;
  long quantidade;

  //tipos reais
  float preco;
  double receber;

  //tipo caracteres 
  char letra;

  //logico
  boolean escolha;



  
  //Metodos get and set
  

  public byte getIdade() {
    return idade;
  }

  public void setIdade(byte idade) {
    this.idade = idade;
  }

  public short getNumero() {
    return numero;
  }

  public void setNumero(short numero) {
    this.numero = numero;
  }

  public int getCodigo() {
    return codigo;
  }

  public void setCodigo(int codigo) {
    this.codigo = codigo;
  }

  public long getQuantidade() {
    return quantidade;
  }

  public void setQuantidade(long quantidade) {
    this.quantidade = quantidade;
  }

  public float getPreco() {
    return preco;
  }

  public void setPreco(float preco) {
    this.preco = preco;
  }

  public double getReceber() {
    return receber;
  }

  public void setReceber(double receber) {
    this.receber = receber;
  }

  public char getLetra() {
    return letra;
  }

  public void setLetra(char letra) {
    this.letra = letra;
  }

  public boolean isEscolha() {
    return escolha;
  }

  public void setEscolha(boolean escolha) {
    this.escolha = escolha;
  }
}
