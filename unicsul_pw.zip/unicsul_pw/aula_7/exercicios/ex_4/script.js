function calcular() {

  const alturaDegraus = document.querySelector("#alturaDegraus").value
  const altura = document.querySelector("#altura").value

  const total = altura / alturaDegraus

  const resultado = document.querySelector("#result")
  
  resultado.value = total.toFixed(0)

}
