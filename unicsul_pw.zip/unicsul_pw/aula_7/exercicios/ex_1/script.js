document.querySelector("body").innerHTML = "<div class='meuNome'><h1>LUCAS VITAL DE MELO</h1></div>";

