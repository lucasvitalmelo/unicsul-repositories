function calcular() {

  const base = document.querySelector("#base").value
  const altura = document.querySelector("#altura").value

  const area = (base * altura) / 2

  const resultado = document.querySelector("#result")
  
  resultado.value = area

}
