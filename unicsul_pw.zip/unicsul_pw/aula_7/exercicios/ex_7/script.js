let conteudo = "<table><tr>ID</tr><tr>Nomes</tr></table>";

document.querySelector("#tab").innerHTML = conteudo;