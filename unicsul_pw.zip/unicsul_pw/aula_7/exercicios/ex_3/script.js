
let MyName = document.querySelector("#nome")
let age = document.querySelector("#idade")

let getName = prompt("Qual seu nome? ")
let yearBirth = prompt("E que ano você nasceu?")
let currentYear = prompt("Em que ano estamos?")

const result = currentYear - yearBirth

MyName.value = getName
age.value = result + " Anos"
