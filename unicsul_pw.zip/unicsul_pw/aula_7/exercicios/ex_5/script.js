function calcular() {

  const nota1 = document.querySelector("#n1").value
  const nota2 = document.querySelector("#n2").value
  const nota3 = document.querySelector("#n3").value

  const n1 = parseInt(nota1)
  const n2 = parseInt(nota2)
  const n3 = parseInt(nota3)

  const total = (n1 + n2 + n3) / 3

  console.log(total)
  
  const resultado = document.querySelector("#result")
  
  if(total <= 4){
    resultado.value = "Reprovado"
  } else if(total > 4 && total <= 6){
    resultado.value = "Exame"
  } else {
    resultado.value = "Aprovado" 
  }
}