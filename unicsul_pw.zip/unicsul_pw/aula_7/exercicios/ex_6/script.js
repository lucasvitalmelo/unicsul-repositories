let nomes = [];

while (true) {
  let nome = prompt("Digite um nome: ");

  if (nome == null) {
    break;
  } else {
    nomes.push(nome);
  }
}
console.log(nomes);

let tabela = document.querySelector("tbody");

tabela.innerHTML = `
  <thead>
    <th>
      Índice
    </th>
    <th>
      Nomes
    </th>
  </thead>
  `;
nomes.forEach((nome, index) => {
  tabela.innerHTML += `
      <tr>
        <td id="index">${index}</td>

        <td>${nome}</td>
      </tr>
      `;
});
