function AumentoDeSalario(){
  const salario = document.querySelector('#salario').value
  const porcentagem = document.querySelector('#aumento').value

  const aumento =  parseFloat(salario) + (parseFloat(salario) * (parseFloat(porcentagem) / 100))

  const result = document.querySelector('#result1')

  result.value = aumento.toFixed(2)
}

function mediaDeValores () {
  const n1 = document.querySelector ('#nota1').value
  const n2 = document.querySelector ('#nota2').value
  const n3 = document.querySelector ('#nota3').value
  const n4 = document.querySelector ('#nota4').value

  const media = (parseInt(n1) + parseInt(n2) + parseInt(n3) + parseInt(n4)) / 4

  const result = document.querySelector ('#result2')

  result.value = media
}

function bhaskara() {
  const ax = document.querySelector('#a').value
  const bx = document.querySelector('#b').value
  const cx = document.querySelector('#c').value

  const a = parseInt(ax)
  const b = parseInt(bx)
  const c = parseInt(cx)

  const delta = b * b - 4 * a * c
  
  const x1 = (-b + Math.sqrt(delta)) / (2 * a).toFixed(2)
  const x2 = (-b - Math.sqrt(delta)) / (2 * a).toFixed(2)

  const x1result = document.querySelector('#x1')
  const x2result = document.querySelector('#x2')
  
  x1result.value = x1;
  x2result.value = x2;
}