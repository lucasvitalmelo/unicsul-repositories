function alertaTamanho(){
  let tamanho = document.querySelector("#tam").value;
  document.querySelector("#texto").style.fontSize = tamanho+"pt";
}

document.querySelector("#btn1").onclick = alertaTamanho

function mudarCor(cor){
  document.querySelector("#texto").style.color = cor;
}

document.querySelector("#btn2").addEventListener("click", function(){
  mudarCor("red");
})
document.querySelector("#btn3").addEventListener("click", function(){
  mudarCor("blue");
})
document.querySelector("#btn4").addEventListener("click", function(){
  mudarCor("black");
})
document.querySelector("#btn5").addEventListener("click", function(){
  mudarCor("yellow");
})

function mudarFundo(cor){
  document.querySelector("#texto").style.backgroundColor = cor;
}

document.querySelector("#btn4").onclick = function(){
  mudaFundo("yellow");
}
document.querySelector("#btn5").onclick = function(){
  mudarFundo("black");
}

function alteraTamanhoCaixa(){
  let largura = document.querySelector("#comp").value;
  document.querySelector("#texto").style.width  = largura;
}

document.querySelector("#btn6").onclick = alteraTamanhoCaixa;