"use strict";

function sorteia(){
  // round arredonda o número
  //random gera números aleatórios de 0 a1

  let aleatorio = Math.round(Math.random()*60);
  document.querySelector("#numero").innerHTML = aleatorio;
}
let intervalo = setInterval(sorteia, 1000); // chama a função informada após o tempo estabelecido (500)

function stopInter() {
  clearInterval(intervalo);
}
setTimeout(stopInter, 3000);