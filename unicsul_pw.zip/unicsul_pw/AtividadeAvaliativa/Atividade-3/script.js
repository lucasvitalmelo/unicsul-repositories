"use strict";

const nome = document.querySelector("#nome");
const rgm = document.querySelector("#rgm");

function mostrar() {
  let dados = document.querySelector("#dados");

  dados.innerHTML = "Nome: " + nome.value;
  dados.innerHTML += " - RGM: " + rgm.value;

  console.log(dados);


  dados.style.fontFamily = "verdana"
  dados.style.backgroundColor = "yellow"
  dados.style.fontSize = "50pt"
  dados.style.textAlign = "center"
  dados.style.border = "1px solid"
  dados.style.borderRadius = "30px"
}
