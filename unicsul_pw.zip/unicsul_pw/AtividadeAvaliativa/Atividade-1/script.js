"use strict";

let listaIdade = [];
let listaPeso = [];
let listaAltura = [];
let pesoAltura = 0;

function guardar() {
  let idade = document.querySelector("#idade");
  let peso = document.querySelector("#peso");
  let altura = document.querySelector("#altura");

  if (idade.value && peso.value && altura.value) {
    listaIdade.push(idade.value);
    listaPeso.push(peso.value);
    listaAltura.push(altura.value);

    if (peso.value >= 90 && altura.value >= 1.5) {
      pesoAltura++;
    }
  } else {
    alert("Todos os campos são obrigatórios!");
  }
}

function calcular() {
  let tabela = document.querySelector("table tbody");
  tabela.innerHTML = null;
  document.querySelector("article p span").innerHTML = pesoAltura;

  listaIdade.forEach((idade, index) => {
    tabela.innerHTML += `
       <tr>
         <td>${idade}</td>
         <td>${listaPeso[index]}</td>
         <td>${listaAltura[index]}</td>
       </tr>
    `;
  });
  listaIdade = [];
  listaPeso = [];
  listaAltura = [];
  pesoAltura = 0;
}
