"use strict";


let numeros = [];

let pares = 0;
let impares = 0;

function gerar() {
  while (numeros.length < 10) {
    let gerados = Math.floor(Math.random() * 100);
    if (gerados % 2 == 0) {
      pares += gerados;
    } else {
      impares += gerados;
    }

    numeros.push(gerados);
  }
  console.log(pares, impares);

  let tabela = document.querySelector("tbody tr");
  numeros.forEach((numeros) => {
    tabela.innerHTML += `
    <td>${numeros}</td>
    `;
  });

  let par = document.querySelector("#pares");
  let impar = document.querySelector("#impares");

  par.innerHTML += `<strong>${pares}</strong>`;
  impar.innerHTML += `<strong>${impares}</strong>`;
}
