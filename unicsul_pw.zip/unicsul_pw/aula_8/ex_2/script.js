function calcular() {

  const salario = Number(document.querySelector("#salario").value)

console.log(salario)

  const ir = document.querySelector("#result");

  if (salario <= 1434) {

    ir.value = "Isento";

  } else if (salario > 1434 && salario <= 2150) {

    const porcentagem = salario / 100;
    ir.value = (7.5 * porcentagem + salario).toFixed(2)

  } else if (salario > 2150 && salario < 2866) {

    const porcentagem = salario / 100;
    ir.value = (15 * porcentagem + salario).toFixed(2)

  } else if (salario >= 2866 && salario <= 3582) {

    const porcentagem = salario / 100;
    ir.value = (22.5 * porcentagem + salario).toFixed(2)

  } else { 
    
    const porcentagem = salario / 100;
    ir.value = (27.5 * porcentagem + salario).toFixed(2)

  }
}
