
function somar() {

  const v1 = Number(document.querySelector("#valor1").value)
  const v2 = Number(document.querySelector("#valor2").value)

  const result = v1 + v2

  const total = document.querySelector("#result")
  
  total.value = result.toFixed(2)
}
function subtrair() {

  const v1 = Number(document.querySelector("#valor1").value)
  const v2 = Number(document.querySelector("#valor2").value)

  const result = v1 - v2
  
  const total = document.querySelector("#result")
  
  total.value = result.toFixed(2)
}
function multiplicar() {
  const v1 = Number(document.querySelector("#valor1").value)
  const v2 = Number(document.querySelector("#valor2").value)

  const result = v1 * v2
  
  const total = document.querySelector("#result")
  
  total.value = result.toFixed(2)
}
function dividir() {
  const v1 = Number(document.querySelector("#valor1").value)
  const v2 = Number(document.querySelector("#valor2").value)

  const result = v1 / v2
  
  const total = document.querySelector("#result")
  
  total.value = result.toFixed(2)
}