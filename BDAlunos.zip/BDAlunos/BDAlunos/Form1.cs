﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BDAlunos
{
    public partial class Form1 : Form
    {
        private MySqlConnection conn;
        private MySqlDataReader rd;
        private MySqlCommand cmd;
        private String sql;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server=localhost; user id=root; password=root; database=universidade");
            conn.Open();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            sql = "INSERT INTO alunos (id, nome, curso) VALUES (" + txtId.Text + ", '" + txtNome.Text + "', '" + txtCurso.Text + "' )";
            cmd = new MySqlCommand(sql, conn);

            int retorno = cmd.ExecuteNonQuery();
            if (retorno > 0)
            {
                MessageBox.Show("Cadastrado com sucesso!");
            }
            else
            {
                MessageBox.Show("Erro ao cadastrar!");
            }
            cmd.Dispose();

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            sql = "SELECT * FROM ALUNOS where id = " + txtId.Text;
            cmd = new MySqlCommand(sql, conn);

            rd = cmd.ExecuteReader();

            if(rd.Read())
            {
                txtNome.Text = rd.GetString("nome");
                txtCurso.Text = rd.GetString("curso");
            }
            else
            {
                MessageBox.Show("Não encontrado!");
            }
            cmd.Dispose();
            rd.Close();

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {

            try
            {
                sql = "UPDATE alunos SET nome ='" + txtNome.Text + "', curso = '" + txtCurso.Text + "' WHERE id =" + txtId.Text;
                cmd = new MySqlCommand(sql, conn);
                int retorno = cmd.ExecuteNonQuery();

                if (retorno > 0)
                {
                    MessageBox.Show("Alterado com sucesso!");
                }
            }
            catch(Exception error)
            {
                MessageBox.Show("Erro ao alterar" + error);
            }
           
           
            cmd.Dispose();
            
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {

            sql = "DELETE FROM alunos WHERE id =" + txtId.Text;
            cmd = new MySqlCommand(sql, conn);
            int retorno = cmd.ExecuteNonQuery();

            if (retorno > 0)
            {
                MessageBox.Show("Excluido com sucesso!");
            }
            else
            {
                MessageBox.Show("Erro ao excluir");
            }
            cmd.Dispose();

        }
    }
}
