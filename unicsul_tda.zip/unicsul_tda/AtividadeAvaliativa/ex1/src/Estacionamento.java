import java.util.Scanner;

public class Estacionamento {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.println("\n\n--------------- Estacionamento ---------------");

        System.out.print("\nHora da entrada: ");
        int he = scan.nextInt();

        System.out.print("Minuto da entrada: ");
        int me = scan.nextInt();

        System.out.print("Hora da saida: ");
        int hs = scan.nextInt();

        System.out.print("Minuto da saida: ");
        int ms = scan.nextInt();

        if(he < 6 || hs > 18){
            System.out.println("\nO estacinamento está fechado!");
        } else {

            int hora = hs - he ;
            int minuto = ms - me;
            
        if(minuto > 0){
            hora++;
        }

        if(hora == 1){
            float pag = 4;
            System.out.println("\nValor a ser pago R$" + String.format("%.2f", pag));
        } else if (hora == 2){
            float pag = 6;
            System.out.println("\nValor a ser pago R$" + String.format("%.2f", pag));
        } else if (hora > 2){
            int adicional = hora - 2;
            float pag = 6 + adicional;
            System.out.println("\nValor a ser pago R$" + String.format("%.2f", pag));
        }
    }
        
        scan.close();
    }
}