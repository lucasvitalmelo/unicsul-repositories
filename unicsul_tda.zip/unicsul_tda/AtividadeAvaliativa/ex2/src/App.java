import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        
        boolean continuar = true;
        
        String p1 = "Inflamável";
        int pesquisaP1 = 0;

        String p2ou3ou4 = "Limpeza e Utensílios Domésticos";
        int pesquisaP2ou3ou4 = 0;
        
        String p5ou6 = "Higiene Pessoal";
        int pesquisaP5ou6 = 0;
        
        String p7 = "Alimento não perecível";
        int pesquisaP7 = 0;
        
        String p8ou9 = "Alimento perecível";
        int pesquisaP8ou9 = 0;
        
        String p10ou11 = "Vestuário";
        int pesquisaP10ou11 = 0;
        
        while (continuar) {
            System.out.println("\n---------------------------------- ");
            System.out.print("Digite o código do produto: ");
            int cod = scan.nextInt();
            System.out.println("----------------------------------\n");
            
            if (cod == 1) {
                System.out.println("------------ Produto ------------");
                pesquisaP1++;
                System.out.print(p1);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP1);
            } else if (cod == 2 || cod == 3 || cod == 4) {
                pesquisaP2ou3ou4++;
                System.out.println("------------ Produto ------------");
                System.out.print(p2ou3ou4);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP2ou3ou4);
            } else if (cod == 5 || cod == 6) {
                pesquisaP5ou6++;
                System.out.println("------------ Produto ------------");
                System.out.print(p5ou6);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP5ou6);
            } else if (cod == 7) {
                pesquisaP7++;
                System.out.println("------------ Produto ------------");
                System.out.print(p7);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP7);
            } else if (cod == 8 || cod == 9) {
                pesquisaP8ou9++;
                System.out.println("------------ Produto ------------");
                System.out.print(p8ou9);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP8ou9);
            } else if (cod == 10 || cod == 11) {
                pesquisaP10ou11++;
                System.out.println("------------ Produto ------------");
                System.out.print(p10ou11);
                System.out.println("\n\nQuantidade de consultas: " + pesquisaP10ou11);
            } else {
                
                System.out.println("Inválido");
                
            }
            
            System.out.print("\n\nDeseja continuar: (S/N) ");
            char sN = scan.next().toUpperCase().charAt(0);
            
            while (true) {
                if (sN == 'S') {
                    break;
                } else if (sN == 'N'){
                    continuar = false;
                    break;

                }
            }
        }
        scan.close();
    }
}
