import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("Digite um número: ");
        int n = scan.nextInt();

        for(int i = n; i >= 0; i--) {
            String x = "";
            for(int j = 0; j < i; j++){
                x = x + "*";
            }
            System.out.println(x);
        }
        
    }
}
