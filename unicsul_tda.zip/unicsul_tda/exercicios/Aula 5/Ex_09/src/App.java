import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\nQuantidade de habitantes: ");
        int population = scan.nextInt();

        float avarageAge = 0;
        int mans = 0;
        float avarageSalary = 0;
        int lowSalaryWoman = 0;

        int i = 0;
        while (i < population) {
            System.out.print("\nDige 'M' para Masculino ou 'F' para Feminino: ");
            char sex = scan.next().charAt(0);

            if (sex == 'M' || sex == 'm' || sex == 'F' || sex == 'f') {

                if (sex == 'M' || sex == 'm') {

                    System.out.print("Digite a Idade: ");
                    int age = scan.nextInt();

                    System.out.print("Digite o Salario: ");
                    float salary = scan.nextFloat();

                    avarageAge = avarageAge + age;

                    avarageSalary = avarageSalary + salary;
                    mans++;
                    i++;

                } else if (sex == 'F' || sex == 'f') {

                    System.out.print("Digite a Idade: ");
                    int age = scan.nextInt();

                    System.out.print("Digite o Salario: ");
                    float salary = scan.nextFloat();

                    avarageAge = avarageAge + age;
                    if (salary < 600) {
                        lowSalaryWoman++;
                    }

                    i++;

                }

            } else {
                System.out.print("**** Sexo invalido ****");

            }

        }

        System.out.println("\nMedia de idedade dos habitantes: " + avarageAge / population);
        System.out.println("Média de sálario dos homens: " + avarageSalary / mans);
        System.out.println("QUantidade de mulheres com salário abaixo de R$600.00: " + lowSalaryWoman);

        scan.close();

    }
}
