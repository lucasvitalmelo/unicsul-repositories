// 1 - Faça um algoritmo que imprima os números pares entre 0 e 100

public class App {
    public static void main(String[] args) throws Exception {
        for(int i = 0; i <= 100; i = i + 1) {

            if((i % 2) == 0) {
                System.out.println(i);
            }     
        }
    }
}
