import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\nQuantos valores serão calculados: ");
        int numberOfValues = scan.nextInt();

        int positive = 0;
        int negative = 0;
        int current = 0;

        int i = 1;
        while (i<=numberOfValues) {
            System.out.print("Digite o valor: ");
            int value = scan.nextInt();
            
            if(value > 0){
                positive++;
            }
            else if(value < 0){
                negative++;
            }

            if(value < current){
                current = value;
            }
            i++;
        }

        System.out.println("Positivos: " + positive);
        System.out.println("Negativos: " + negative);

        scan.close();
    }
}
