import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        int approved = 0;
        int i = 1;
        while (i <= 80) {
            System.out.print("\nNota de '0' à '10': ");

            float note = scan.nextInt();

            if (note >= 0 && note <= 10) {

                if (note >= 6.0) {
                    approved++;

                }
                i++;
                
            } else {
                System.out.println("-----------------------");
                System.out.println("**** NOTA INVALIDA ****");
                System.out.println("-----------------------");
            }

        }
        System.out.println("\n\n\nAPROVADOS" + approved);
        scan.close();
    }
}
