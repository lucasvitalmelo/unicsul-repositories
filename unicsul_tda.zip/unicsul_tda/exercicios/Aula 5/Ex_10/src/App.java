public class App {
    public static void main(String[] args) throws Exception {
        
        int a = 1;
        while (a <=10) {
            System.out.println("1 x " + a + " = " + 1 * a);
            a++;
        }

        System.out.println("============");

        int b = 1;
        while (b <= 10) {
            System.out.println("2 x " + b + " = " + 2 * b);
            b++;
        }

        System.out.println("============");

        int c = 1;
        while (c <= 10) {
            System.out.println("3 x " + c + " = " + 3 * c);
            c++;
        }

        System.out.println("============");

        int d = 1;
        while (d <= 10) {
            System.out.println("4 x " + d + " = " + 4 * d);
            d++;
        }

        System.out.println("============");

        int e = 1;
        while (e <= 10) {
            System.out.println("5 x " + e + " = " + 5 * e);
            e++;
        }

        System.out.println("============");

        int f = 1;
        while (f <= 10) {
            System.out.println("6 x " + f + " = " + 6 * f);
            f++;
        }

        System.out.println("============");

        int g = 1;
        while (g <= 10) {
            System.out.println("7 x " + g + " = " + 7 * g);
            g++;
        }

        System.out.println("============");

        int h = 1;
        while (h <= 10) {
            System.out.println("8 x " + h + " = " + 8 * h);
            h++;
        }

        System.out.println("============");

        int i = 1;
        while (i <= 10) {
            System.out.println("9 x " + i + " = " + 9 * i);
            i++;
        }

        System.out.println("============");

        int j = 1;
        while (j <= 10) {
            System.out.println("10 x " + j + " = " + 10 * j);
            j++;
        }

        
    }
}
