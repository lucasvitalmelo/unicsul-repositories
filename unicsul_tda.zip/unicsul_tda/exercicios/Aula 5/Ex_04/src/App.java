// Escreva um algoritmo que leia a quantidade de valores que serão processados,
// depois leia os valores e calcule a média dos mesmos. Utilize a estrutura de
// repetição PARA.

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\n==== Calculadora de Média ====\n");
        System.out.print("\nQuantos valores será calculado: ");
        int n = scan.nextInt();
        float acum = 0;

        for (int i = 1; i <= n; i++) {
            System.out.print("\nDigite o valor: ");
            float valor = scan.nextFloat();

            acum = valor + acum;
        }
        System.out.print("\n---------------------\n");
        System.out.print("A média é: " + acum / n);
        System.out.print("\n---------------------");

        scan.close();
    }
}
