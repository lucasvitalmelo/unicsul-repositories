import java.util.Scanner;
import java.util.Locale;


public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        scan.useLocale(Locale.US);
        
        System.out.print("\nDigite a quantidade de Pessoas ");
        int person = scan.nextInt();
        int i = 1;


        int numberOfWomans = 0;
        int numberOfMans = 0;
        float man = 0;
        float woman = 0;

        while (i <= person) {
            
            System.out.print("\nDigite '1' para Mulher e '2' para Homem: ");
            int sex = scan.nextInt();
            
            
            System.out.print("Digite a altura: ");
            float height = scan.nextFloat();
            
            if(sex == 1){
                numberOfWomans++;
                woman = woman + height;
            }
            else{
                numberOfMans++;
                man = man + height;
            }
            
            i++;
        }
        System.out.println("Média de altura das Mulheres é: " + woman / numberOfWomans);
        System.out.println("Média de altura dos Homens é: " + man / numberOfMans);
        System.out.println(woman);
        System.out.println(numberOfWomans);

        System.out.println(man);
        System.out.println(numberOfMans);

        scan.close();
    }
}
