import java.util.Random;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Random generator = new Random();
        Scanner scan = new Scanner(System.in);

        System.out.print("\nDigite um número para o compudador adivinhar: ");
        int guessWhat = scan.nextInt();

        int number = 0;

        int attemptsCpu = 0;

        while(number != guessWhat) {
            
            number = generator.nextInt(10);
            
            attemptsCpu++;

            System.out.println("\nComputador: " + number);
        }
        
        System.out.println("\nApós " + attemptsCpu + " tentativas o computador acertou que número digitado era o " + number);
        scan.close();
    }
}
