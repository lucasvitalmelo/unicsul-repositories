// 3- Faça um algoritmo que leia um valor n, inteiro e positivo, calcule e mostre a
// seguinte soma:

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\nDigite um número inteiro: ");
        int n = scan.nextInt();

        float sum = 1;
        int i = 2;

        while(i<=n) {
            float decimal = i;
            sum = sum + (1 / decimal);

            i++;
        }
        System.out.println(sum);
        
        scan.close();
    }
}
