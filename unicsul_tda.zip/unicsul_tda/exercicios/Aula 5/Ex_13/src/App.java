import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Insira um número ímpar: ");
        int number = scan.nextInt();

        if (number % 2 != 0) {
            int asterisk = 1;
            int space = (number - 1) / 2;
            for (int i = 1; space > 0; i++) {
                for (int count = 1; count <= space; count++) {
                    System.out.print(" ");
                }
                for (int count = 1; count <= asterisk; count++) {
                    System.out.print("*");
                }
                space--;
                asterisk += 2;
                System.out.println();
            }

            for (int j = 1; asterisk > 0; j++) {

                for (int count = 1; count <= space; count++) {
                    System.out.print(" ");
                }

                for (int count = 1; count <= asterisk; count++) {
                    System.out.print("*");
                }

                space++;
                asterisk -= 2;
                System.out.println();
            }

        }
        scan.close();
    }
}