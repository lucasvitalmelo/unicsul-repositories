// Escreva um algoritmo que leia a quantidade de valores que serão processados,
// depois leia os valores e calcule a média dos mesmos. Utilize a estrutura de
// repetição PARA.

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\n====================================");
        System.out.print("\nQuantos valores será calculado: ");
        int n = scan.nextInt();
        float newValue = 0;
        
        int i = 1;
        while (i <= n) {  
            
            System.out.print("\n-----------------\n");
            System.out.print("Digite o valor: ");
            float value = scan.nextFloat();
            
            newValue = newValue + value;
            
            i++; 
         }

         scan.close();
         System.out.print("\nA média é: " + newValue / n);
    }
 }