# 1- Escreva um algoritmo que solicite um número ao usuário. Caso
# seja digitado um valor entre 0 e 9, mostre: “valor correto”, caso
# contrário mostre: “valor incorreto”.
n = int(input("Digite um número: "))

if n == 0 or n == 1 or n == 2 or n == 3 or n == 4 or n == 5 or n == 6 or n == 7 or n == 8 or n == 9:
  print("")
  print("Valor correto!")
else:
  print("Valor incorreto!")