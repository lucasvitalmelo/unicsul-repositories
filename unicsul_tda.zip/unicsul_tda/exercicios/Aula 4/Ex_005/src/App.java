import java.util.Scanner;
import java.math.*;
public class App {
    public static void main(String[] args) throws Exception {
        float a, b, c;
        Double delta, x1, x2;

        Scanner asd = new Scanner(System.in);

        System.out.println("Digite a");
        a = Float.parseFloat(asd.nextLine());
        System.out.println("Digite b");
        b = Float.parseFloat(asd.nextLine());
        System.out.println("Digite c");
        c = Float.parseFloat(asd.nextLine());

        delta = Math.pow(b*2)-4*a*c;

        if(delta < 0){
            System.out.println("NOT EXISTING");
        }
        else{
            x1 = (-b+Math.sqrt(delta))/2*a;
            x2 = (-b-Math.sqrt(delta))/2*a;
        }

    }
}
