# 4- Faça um algoritmo que receba o código correspondente ao cargo de
# um funcionário e seu salário atual e mostre o cargo, o valor do
# aumento e seu novo salário. Os cargos estão na tabela a seguir, utilize


# Código	    Cargo		      Percentual
# ---------------------------------------
# 1	          Escrituario	  50%
# 2	          Secretario	  35%
# 3	          Caixa		      20%
# 4	          Gerente		    10%
# 5	          Diretor		    Não tem aumento

print("")
codigo = int(input("Digite o código do funcionário: "))
print("")

salario = float(input("Digite o salario do mesmo: "))

if codigo == 1:
  print("")
  print("Salário atual:", salario)
  print("Novo salario",(salario * 0.50) + salario)
elif codigo == 2:
  print("")
  print("Salário atual:", salario)
  print("Novo salario",(salario * 0.35) + salario)
elif codigo == 3:
  print("")
  print("Salário atual:", salario)
  print("Novo salario",(salario * 0.20) + salario)
elif codigo == 4:
  print("")
  print("Salário atual:", salario)
  print("Novo salario",(salario * 0.10) + salario)
else:
  print("")
  print("Não tem aumento")