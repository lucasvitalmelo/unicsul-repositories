# 2- Crie um algoritmo que solicite ao usuário o seu turno de trabalho e
# a quantidade de horas trabalhadas, calcule e mostre o valor do
# salário. Considere os valores de horas a seguir, de acordo com o
# turno de trabalho. Caso o turno seja igual a ‘N’ (utilize um caractere
# para representar) o valor da hora trabalhada é R$ 45,00, caso
# contrário é R$ 37,50

print("")
turno = str(input("Digite 'M' para turno da Manhã | Digite 'N' para turno da Noite :"))
print("")
horas = int(input("Digite a quantidade de horas trabalhadas: "))

if turno == 'N' or turno == 'n':
  print("")
  print("Sálario: R$",horas * 45.00)
else:
  print("")
  print("Sálario: R$",horas * 37.50)