import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);


        int acum = 0;
        int quantidade = 0;
        String controle = "".toLowerCase();
        
        while(true) {
            System.out.println("\n\nDigite um número :");
            int entrada = scan.nextInt();
            
            acum = acum + entrada;

            quantidade++;

            System.out.println("\n****** Quer continuar? ******");
            System.out.println("'S' para sim || 'N' para não :");
            controle = scan.next();

            if(controle.charAt(0) == 'n'){
                break;
            }
        }

        System.out.print("\n\n\n Média " + acum / quantidade);


        scan.close();
    }
}
