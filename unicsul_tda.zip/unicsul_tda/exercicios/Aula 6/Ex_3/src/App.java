import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\n\nDigite a quantidade de mercadoria: ");
        int mercadoria = scan.nextInt();

        System.out.print("Digite o valor de cada mercadoria: ");
        double valor = scan.nextDouble();

        double total = mercadoria * valor;

        double media = total / mercadoria;

        System.out.println("\nValor total: R$" + total);
        System.out.println("Média de cada mercadoria: R$" + media);

        scan.close();
    }
}
