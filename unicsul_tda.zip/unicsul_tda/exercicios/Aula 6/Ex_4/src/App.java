import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\n\nQuantos numeros serão calculados: ");
        int quantidade = scan.nextInt();

        double acum = 0;

        for(int i = 1; i <= quantidade; i++) {
            System.out.print("\nDigite um número: ");
            int n = scan.nextInt();

            acum = acum + n;
        };

        System.out.println("A média é: " + acum /quantidade);
        scan.close();
    }
}
