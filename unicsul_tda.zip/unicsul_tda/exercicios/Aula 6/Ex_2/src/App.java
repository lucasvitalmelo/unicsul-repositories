import java.util.Scanner;
import java.time.LocalDate;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        int ano = LocalDate.now().getYear();
   
        System.out.print("\n\nDigite o Id do empregado: ");
        int id = scan.nextInt();
        
        System.out.print("\n\nAno de nascimento: ");
        int anoNascimento = scan.nextInt();
        
        System.out.print("Digite o ano que ingressou na empresa: ");
        int entradaEmpresa = scan.nextInt();
        
        int idade = ano - anoNascimento;

        int anosDeEmpresa = ano - entradaEmpresa;


        if(idade >= 65){
            System.out.println("Requer Aposentadoria");

        } else if ( anosDeEmpresa >= 30){
            System.out.println("Requer Aposentadoria");

        } else if ( idade >= 60 && anosDeEmpresa >= 25){
            System.out.println("Requer Aposentadoria");

        } else {
            System.out.println("Não requer");

        }
        
        System.out.print("\n\nId: " +id+ "\nIdade: " + idade + "\nAnos trabalhados: " + anosDeEmpresa);

        scan.close();
    }
}