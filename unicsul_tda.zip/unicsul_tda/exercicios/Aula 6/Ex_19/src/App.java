import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        

            boolean continuar = true;

            while (continuar) {

                System.out.println("-----------CALCULAR-----------");
                System.out.println("");
                System.out.println("| 1 | Somar dois números");
                System.out.println("| 2 | Subtrair dois números");
                System.out.println("| 3 | Multiplicar dois números");
                System.out.println("| 4 | Sair");

                System.out.print("\nEscolha um opção: ");

                char resp = scan.nextLine().charAt(0);

                if(resp == '1'){
                    Somar(scan);
                } else if(resp == '2'){
                    Subtrair(scan);
                } else if(resp == '3'){
                    Multiplicar(scan);
                } else if(resp == '4'){
                    System.out.println("Programa finalizado!");
                }

                
            }

        scan.close();
    }

    public static void Somar(Scanner scan) {

        System.out.print("\nDigite o primeiro número: ");
        int n1 = scan.nextInt();

        System.out.print("Digite o segundo número: ");
        int n2 = scan.nextInt();

        System.out.println("\nA some de " + n1 + " + " + n2 + " = " + (n1 + n2));
    }

    public static void Subtrair(Scanner scan) {

        System.out.print("\nDigite o primeiro número: ");
        int n1 = scan.nextInt();

        System.out.print("Digite o segundo número: ");
        int n2 = scan.nextInt();

        System.out.println("\nA subtração de " + n1 + " - " + n2 + " = " + (n1 - n2));
    }

    public static void Multiplicar(Scanner scan) {

        System.out.print("\nDigite o primeiro número: ");
        int n1 = scan.nextInt();

        System.out.print("Digite o segundo número: ");
        int n2 = scan.nextInt();

        System.out.println("\nA multiplicação de " + n1 + " x " + n2 + " = " + (n1 * n2));
    }
}
