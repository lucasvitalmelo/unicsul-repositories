import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
    
        for(int i = 0; i < 10; i++) {
            System.out.print("\n\nDigite o salario: ");
            double salario = scan.nextDouble();

            if(salario <= 1500) {

                System.out.println("\nReceberá um aumento de 10% sobre o salario atual!");
                System.out.println("Salario atual : " + salario);
                System.out.println("Novo salario : " + (salario + (0.10 * salario)));
                
            } else if(salario > 1500 && salario <= 3000){
                
                System.out.println("\nReceberá um aumento de 2% sobre o salario atual!");
                System.out.println("Salario atual : " + salario);
                System.out.println("Novo salario : " + (salario + (0.02 * salario)));

            } else {
                System.out.println("Não receberá o aumento!");
            }


        }

        scan.close();
    }
}
