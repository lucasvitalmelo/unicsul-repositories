import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\nDigite a quantidade de vezes: ");
        int n = scan.nextInt();

        for(int i = 1; i <= n;){
            System.out.println(i+", 1 2 3 4 5 6 7 8 9 10");
            i++;
        }
        scan.close();
    }
}
