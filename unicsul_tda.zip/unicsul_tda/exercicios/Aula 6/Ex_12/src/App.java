import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        int pass = 4531;

        while (true) {
            System.out.println("\nLogin: Admin");
            System.out.print("Senha: ");
            int password = scan.nextInt();

            if (password == pass) {
                System.out.println("\nAcesso liberado!");
                break;
            } else {
                System.out.println("\n***************");
                System.out.println("Acesso negado!");
                System.out.println("***************");
            }
        }

        scan.close();
    }
}
