import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        int min = 15;
        int max = 18;

        int idade15 = 0;
        int idade16 = 0;
        int idade17 = 0;

        for(int i = 0; i <= 500; i++) {
            int idade = (int) (Math.random()*(max-min)) + min;

            if(idade == 15) {
                idade15++;

            } else if(idade == 16) {
                idade16++;

            } else if(idade == 17) {
                idade17++;
            }
        }

        System.out.println(idade15 + " alunos, não são eleitores.");
        System.out.println(idade16 + idade17 + " alunos podem votar.");

        scan.close();
    }
}
