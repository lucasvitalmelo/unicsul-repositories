import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        int simHomens = 0;
        int simMulheres = 0;
        int naoMulheres = 0;

        for (int i = 0; i <= 200; i++) {
            System.out.print("'F' para Feminino ou 'M' para Masculino :");
            String sexo = scan.next().toUpperCase();

            if (sexo.charAt(0) == 'F') {
                System.out.println("Tem interesse no produto ?");
                System.out.println("'S' para Sim ou 'N' para Não");
                String simNao = scan.next().toUpperCase();

                if (simNao.charAt(0) == 'S') {
                    simMulheres++;
                } else {
                    naoMulheres++;
                }
            } else if (sexo.charAt(0) == 'M') {
                System.out.println("Tem interesse no produto ?");
                System.out.println("'S' para Sim ou 'N' para Não");
                String simNao = scan.next().toUpperCase();

                if (simNao.charAt(0) == 'S') {
                    simHomens++;
                }
                ;
            }
        }

        System.out.println(simHomens + simMulheres + " pessoas disseram que sim.");
        System.out.println(naoMulheres + " disseram não.");


        scan.close();
    }
}
