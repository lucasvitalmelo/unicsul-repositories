import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("\n\nDigite o último número da placa: ");
        int n = scan.nextInt();

        System.out.println();
        if (n == 1 || n == 2) {
            System.out.println("------------------------");
            System.out.println("Rodízio na segunda-feira");
            System.out.println("------------------------");
        } else if (n == 3 || n == 4) {
            System.out.println("------------------------");
            System.out.println("Rodízio na terça-feira");
            System.out.println("------------------------");
        } else if (n == 5 || n == 6) {
            System.out.println("------------------------");
            System.out.println("Rodízio na quarta-feira");
            System.out.println("------------------------");
        } else if (n == 7 || n == 8) {
            System.out.println("------------------------");
            System.out.println("Rodízio na quinta-feira");
            System.out.println("------------------------");
        } else if (n == 9 || n == 0) {
            System.out.println("------------------------");
            System.out.println("Rodízio na sexta-feira");
            System.out.println("------------------------");
        }
        scan.close();
    }
}
