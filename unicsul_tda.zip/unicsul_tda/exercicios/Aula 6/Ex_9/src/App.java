import java.util.Scanner;
// import java.util.Random;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        // Random rd = new Random();

        int positivo = 0;
        int negativo = 0;
        int maior = 0;
        int menor = 0;

        boolean controle = true;

        while(true) {

            System.out.print("\n\nDigite um números: ");
            int n = scan.nextInt();

            while(controle) {
                maior = n;
                menor = n;
                controle = false;
            }

            if(n > 0) {
                positivo++;
            } else {
                negativo++;
            }

            if(n > maior){
                maior = n;
            }

            if(n < menor){
                menor = n;
            }

            System.out.println("\n******** Deseja continuar? ********* ");
            System.out.print ("'S' para sim || 'N' para não :");
            String isBreak = scan.next().toLowerCase();

            if(isBreak.charAt(0) == 'n'){
                break;
            }

        }
        System.out.println("\n\n--------- Resultado ---------");
        System.out.println("\nMaior: " + maior);
        System.out.println("Menor: " + menor);

        System.out.println("Quantidade de positivos: " + positivo);
        System.out.println("Quantidade de negativos: " + negativo);

        scan.close();
    }
}
