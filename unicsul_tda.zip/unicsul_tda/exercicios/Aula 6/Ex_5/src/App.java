import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        
        int quantidade = 0;
        double maiorSalario = 0;
        double acumSalario = 0;
        int acumFilhos = 0;
        int percentualMenorSalario = 0;
        
        boolean controleMaiorSalario = true;
        
        while(true){
        
            System.out.print("\nDigite o salario: ");
            double salario = scan.nextDouble();

            acumSalario = acumSalario + salario;

            System.out.print("Digite a quantidade de filhos: ");
            int filhos = scan.nextInt();

            acumFilhos = acumFilhos + filhos;

            quantidade++;

            if(controleMaiorSalario){
                maiorSalario = maiorSalario + salario;

                controleMaiorSalario = false;
            }

            if(maiorSalario < salario){
                maiorSalario = salario;
            }

            if(salario < 150){
                percentualMenorSalario++; 
            }

            if(salario <= 0) {
                break;
            }
        }


            System.out.println("*** Relatório ***");
        
            System.out.println("\n\nMedia de salário: " +  acumSalario / quantidade );
            System.out.println("Média de filhos: " + acumFilhos / quantidade);
            System.out.println("O maior salário é R$" + maiorSalario);
            System.out.println("Percentual de pessoas com salário menor que R$ 150,00 : " + percentualMenorSalario);

            scan.close();
    }
}
