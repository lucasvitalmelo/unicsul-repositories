import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.println("\n\n==== CALCULADORA DE DESCONTO ====");

        System.out.print("\n\nNome do produto: ");
        String nome = scan.next();

        System.out.print("Qual a quantidade: ");
        int quantidade = scan.nextInt();

        System.out.print("Valor unitario: ");
        Double valor = scan.nextDouble();

        if( quantidade <= 5 ){
            Double total = valor * quantidade;
            Double desconto = total - (total * 0.02);
            System.out.println("\nCom desconto de 2% - " + nome +" sairá de R$"+ total + " por R$" + desconto);

        } else if( quantidade > 5 && quantidade <= 10 ){
            Double total = valor * quantidade;
            Double desconto = total - (total * 0.03);
            System.out.println("\nCom desconto de 3% - " + nome +" sairá de R$"+ total + " por R$" + desconto);
        } else {
            Double total = valor * quantidade;
            Double desconto = total - (total * 0.10);
            System.out.println("\nCom desconto de 10% - " + nome +" sairá de R$"+ total + " por R$" + desconto);
        }
        scan.close();
    }
}
