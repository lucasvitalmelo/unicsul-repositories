import java.util.Random;

public class App {
    public static void main(String[] args) throws Exception {
        
        boolean controle = true; 

        int aleatorio = 0;
        int numeroMaior = 0;
        int numeroMenor = 0;
        Random rand = new Random();

        for( int i = 0 ; i < 100 ; i++) {

            aleatorio = rand.nextInt(1000);

            while(controle){
                numeroMaior = aleatorio;
                numeroMenor = aleatorio;
                controle = false;
            }

            if(aleatorio > numeroMaior){
                numeroMaior = aleatorio;
            } else if (aleatorio < numeroMenor){
                numeroMenor = aleatorio;
            }
            
        }

        System.out.println("\nO maior: " + numeroMaior);
        System.out.println("O menor: " + numeroMenor);
    }
}
