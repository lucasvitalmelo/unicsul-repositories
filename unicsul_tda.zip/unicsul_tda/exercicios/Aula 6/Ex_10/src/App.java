import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        float mulheres = 0;
        float homens = 0;

        int qtHomens = 0;
        int qtMulheres = 0;


        while(true){

            System.out.println("\n\nPara Homem digite 'H'");
            System.out.println("Para Mulher digite 'M'");
            System.out.print("? : ");
            String sexo = scan.next().toUpperCase();

            if(sexo.charAt(0) == 'H'){
                System.out.print("\nDigite a altura do homem: ");
                float altura = scan.nextFloat();

                homens = homens + altura;
                qtHomens++;

            } else if(sexo.charAt(0) == 'M'){
                System.out.print("\nDigite a altura da mulher: ");
                float altura = scan.nextFloat();

                mulheres = mulheres + altura;
                qtMulheres++; 

            } else {
                System.out.println("================");
                System.out.println("\nSexo Inválido!");
                System.out.println("================");
            }

            System.out.print("Deseja continuar? \n'S' para Sim \n'N' Para Não : ");
            String isBreak = scan.next().toUpperCase();

            if(isBreak.charAt(0) == 'N'){
                break;
            }
        }

        float mediaHomens = homens / qtHomens;
        float mediaMulheres = mulheres / qtMulheres;


        System.out.println("==========================================");
        System.out.println("\nMedia da altura das mulheres: " + mediaMulheres + "m");
        System.out.println("Media da altura dos homens: " + mediaHomens + "m");
        System.out.println("==========================================");

        scan.close();
    }
}
