import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);

        System.out.print("Digite o salario: ");
        double salario = scan.nextDouble();
        
        System.out.print("Digite o valor de vendas: ");
        double vendas = scan.nextDouble();

        System.out.println("Valor da coissão: R$" + (0.04 * vendas));
        System.out.println("Salario com a comissão: R$" + (salario + (0.04 * vendas)));

        
        scan.close();
    }
}
