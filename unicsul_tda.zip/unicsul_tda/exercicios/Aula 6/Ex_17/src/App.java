import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        

            System.out.println("\nQual o ano de nascimento: ");
            int ano = scan.nextInt();

            System.out.println("\nIdade atual: " + (2020 - ano));
            System.out.println("Idade em 2050: " + (2050 - ano));

        scan.close();
    }
}
