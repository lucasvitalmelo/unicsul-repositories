public class App {
    public static void main(String[] args) throws Exception {
        // 1901 - 2020

        int ano = 1901;

        System.out.println("Anos bissexto: ");

        while (ano <= 2020){
            if (ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0) {
                System.out.println(ano);
            }
            ano++;
        }
    }
}
